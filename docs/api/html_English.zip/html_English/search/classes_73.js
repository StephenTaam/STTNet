var searchData=
[
  ['serversetting',['ServerSetting',['../classstt_1_1system_1_1ServerSetting.html',1,'stt::system']]]
];
