var searchData=
[
  ['shared_5fmemory_5fkey',['SHARED_MEMORY_KEY',['../sttnet_8h.html#a0b80156f23e93853d4f405d8eb823a9b',1,'sttnet.h']]],
  ['shared_5fmemory_5flock_5fkey',['SHARED_MEMORY_LOCK_KEY',['../sttnet_8h.html#ab081726ac6486f3d4c7499a970569a66',1,'sttnet.h']]]
];
