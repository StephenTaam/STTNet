var searchData=
[
  ['day',['day',['../structstt_1_1time_1_1Duration.html#a32a03ec8d3263c6596e1fe15eda5b296',1,'stt::time::Duration']]]
];
