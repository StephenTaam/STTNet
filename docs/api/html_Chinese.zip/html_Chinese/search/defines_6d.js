var searchData=
[
  ['max_5fprocess_5finf',['MAX_PROCESS_INF',['../sttnet_8h.html#a7ca8d8a89923f4741b8c620322506c15',1,'sttnet.h']]],
  ['max_5fprocess_5fname',['MAX_PROCESS_NAME',['../sttnet_8h.html#ad49d6c18040b4ee47b8db7a2aeccc960',1,'sttnet.h']]],
  ['maxfd',['maxFD',['../sttnet_8h.html#ae27515887d4276929f45c1f2e6234105',1,'sttnet.h']]]
];
